import '../scss/styles.scss'
import logo from '../assets/logo-lance.png'

const elemRoot = document.getElementById('root')
elemRoot.classList.add('container')
