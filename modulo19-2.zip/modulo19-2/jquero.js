$("#tirad").hide();
$("#tira").click(function(){
    $("#tirad").toggle();
  }); 

$("#ankd").hide();
$("#ank").click(function(){
      $("#ankd").toggle();
    }); 


$("#brad").hide();
$("#bra").click(function(){
    $("#brad").toggle();
}); 


$("#mosad").hide();
$("#mosa").click(function(){
    $("#mosad").toggle();
}); 

$("#stygd").hide();
$("#styg").click(function(){
    $("#stygd").toggle();
  }); 

$("#tricd").hide();
$("#tric").click(function(){
    $("#tricd").toggle();
  }); 