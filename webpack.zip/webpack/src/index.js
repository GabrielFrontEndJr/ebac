import soma from './calc.js';
import Heading from './components/heading.js';

console.log("Testando a budega di novo");

soma(4, 5);

const heading = new Heading();

heading.create("Israel não é um estado legítimo");