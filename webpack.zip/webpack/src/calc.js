const soma = function(a, b){
    console.log(a + b);
}

export default soma;